// Uncomment the next line to use precompiled headers
#include "pch.h"
// uncomment the next line if you do not use precompiled headers
//#include "gtest/gtest.h"
//
// the global test environment setup and tear down
// you should not need to change anything here
class Environment : public ::testing::Environment
{
public:
    ~Environment() override {}

    // Override this to define how to set up the environment.
    void SetUp() override
    {
        //  initialize random seed
        srand(time(nullptr));
    }

    // Override this to define how to tear down the environment.
    void TearDown() override {}
};

// create our test class to house shared data between tests
// you should not need to change anything here
class CollectionTest : public ::testing::Test
{
protected:
    // create a smart point to hold our collection
    std::unique_ptr<std::vector<int>> collection;

    void SetUp() override
    { // create a new collection to be used in the test
        collection.reset(new std::vector<int>);
    }

    void TearDown() override
    { //  erase all elements in the collection, if any remain
        collection->clear();
        // free the pointer
        collection.reset(nullptr);
    }

    // helper function to add random values from 0 to 99 count times to the collection
    void add_entries(int count)
    {
        assert(count > 0);
        for (auto i = 0; i < count; ++i)
            collection->push_back(rand() % 100);
    }
};

// When should you use the EXPECT_xxx or ASSERT_xxx macros?
// Use ASSERT when failure should terminate processing, such as the reason for the test case.
// Use EXPECT when failure should notify, but processing should continue

// Test that a collection is empty when created.
// Prior to calling this (and all other TEST_F defined methods),
//  CollectionTest::StartUp is called.
// Following this method (and all other TEST_F defined methods),
//  CollectionTest::TearDown is called
TEST_F(CollectionTest, CollectionSmartPointerIsNotNull)
{
    // is the collection created
    ASSERT_TRUE(collection);

    // if empty, the size must be 0
    ASSERT_NE(collection.get(), nullptr);
}

// Test that a collection is empty when created.
TEST_F(CollectionTest, IsEmptyOnCreate)
{
    // is the collection empty?
    ASSERT_TRUE(collection->empty());

    // if empty, the size must be 0
    ASSERT_EQ(collection->size(), 0);
}

/* Comment this test out to prevent the test from running
 * Uncomment this test to see a failure in the test explorer */
//TEST_F(CollectionTest, AlwaysFail)
//{
   // FAIL();
//}

// TODO: Create a test to verify adding a single value to an empty collection
TEST_F(CollectionTest, CanAddToEmptyVector)
{
    // Test to point at collection to see if it is empty
    ASSERT_TRUE(collection->empty());
    
    //Test to see if empty collection set to size of 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(1);

    //Test to see if collection is not empty
    ASSERT_FALSE(collection->empty());

    //if not empty, size of collection should be set to 1
    ASSERT_EQ(collection->size(), 1);
    
}

// TODO: Create a test to verify adding five values to collection
TEST_F(CollectionTest, CanAddFiveValuesToVector)
{
    // Test to point at collection to see if it is empty
    ASSERT_TRUE(collection->empty());

    //Test to see if empty collection set to size of 0
    ASSERT_EQ(collection->size(), 0);

    add_entries(5);

    //Test to see if collection is not empty
    ASSERT_FALSE(collection->empty());

    //if not empty, size of collection should be set to 5
    ASSERT_EQ(collection->size(), 5);
}

// TODO: Create a test to verify that max size is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxSizeGreaterOrEqual) {
   
    // Add 11 entries for tests
    add_entries(20);

    // Test max size is greater than or equal to size for 0 entries
    ASSERT_TRUE(collection->max_size() >= 0);

    // Test max size is greater than or equal to size for 1 entries
    ASSERT_TRUE(collection->max_size() >= 1);

    // Test max size is greater than or equal to size for 5 entries
    ASSERT_TRUE(collection->max_size() >= 5);

    // Test max size is greater than or equal to size for 10 entries
    ASSERT_TRUE(collection->max_size() >= 10);
}

// TODO: Create a test to verify that capacity is greater than or equal to size for 0, 1, 5, 10 entries
TEST_F(CollectionTest, MaxCapacityGreaterOrEqual) {

    // Add 11 entries for tests
    add_entries(20);

    // Test max size is greater than or equal to size for 0 entries
    ASSERT_TRUE(collection->capacity() >= 0);

    // Test max size is greater than or equal to size for 1 entries
    ASSERT_TRUE(collection->capacity() >= 1);

    // Test max size is greater than or equal to size for 5 entries
    ASSERT_TRUE(collection->capacity() >= 5);

    // Test max size is greater than or equal to size for 10 entries
    ASSERT_TRUE(collection->capacity() >= 10);
}
// TODO: Create a test to verify resizing increases the collection
TEST_F(CollectionTest, IncreaseSizeCollection) {

    // Initializes entries
    add_entries(1);

    // Initialize and declare previous value to collection size
    unsigned int initialSize = collection->size();

    // Resize container to hold elements
    collection->resize(15);

    //test to verify true if collection size is greater than initial size of collection
    ASSERT_TRUE(collection->size() > initialSize);
}

// TODO: Create a test to verify resizing decreases the collection
TEST_F(CollectionTest, DecreaseSizeCollection) {

    // initialize entries
    add_entries(15);

    // Initialize and declare previous value to collection size
    unsigned int initialSize = collection->size();

    // Resize container to hold elements
    collection->resize(1);

    //test to verify true if collection size is less than initial size of collection
    ASSERT_TRUE(collection->size() < initialSize);
}

// TODO: Create a test to verify resizing decreases the collection to zero
TEST_F(CollectionTest, DecreaseSizeToZero) {

    // initialize entries
    add_entries(15);

    // Initialize and declare previous value to collection size
    unsigned int initialSize = collection->size();

    //resize collection to 0
    collection->resize(0);

    // Test to verify resize of collection is equal to 0;
    ASSERT_TRUE(collection->size() == 0);
}
// TODO: Create a test to verify clear erases the collection
TEST_F(CollectionTest, VerifyClearEraseCollection) {

    // Add 15 elements
    add_entries(15);

    // Clear collection action
    collection->clear();

    // Verify collection has been resized to 0
    ASSERT_TRUE(collection->size() == 0);
}

// TODO: Create a test to verify erase(begin,end) erases the collection
TEST_F(CollectionTest, VerifyCollectionErased) {
    add_entries(15);

    // Erase the colletion from begin() to end() (all)
    collection->erase(collection->begin(), collection->end());

    // Verify the collection has been resized to 0
    ASSERT_TRUE(collection->size() == 0);
}

// TODO: Create a test to verify reserve increases the capacity but not the size of the collection
TEST_F(CollectionTest, ReserveIncreasesCapacityNotCollectionSize) {
    add_entries(15);

    unsigned int initialCapacity = collection->capacity();
    unsigned int initialSize = collection->size();

    // Request the container be reserved to at least 50
    collection->reserve(50);

    // Verify size is equal but capacity is larger
    ASSERT_TRUE(collection->size() == initialSize);
    ASSERT_TRUE(collection->capacity() > initialCapacity);
}

// TODO: Create a test to verify the std::out_of_range exception is thrown when calling at() with an index out of bounds
// NOTE: This is a negative test
TEST_F(CollectionTest, VerifyOutOfRangeExRunsWhenCallingAtWithOOBIndex) {
    // Define a vector of size 9
    std::vector<int> elements(9);

    // Expect out_of_range exception to be thrown upon callng myvector with out of bound access
    EXPECT_THROW(elements.at(10), std::out_of_range);
}

// TODO: Create 2 unit tests of your own to test something on the collection - do 1 positive & 1 negative
TEST_F(CollectionTest, AddOneElementToCollection) {
    add_entries(15);

    collection->push_back(1); // Adds one element, in this case it adds an element with a value of 1

    ASSERT_TRUE(collection->size() > 15);
    ASSERT_TRUE(collection->at(15) == 1); // check index 15 to make sure it is assigned as 1
}

TEST_F(CollectionTest, RemoveOneElementFromCollection) {
    add_entries(10);

    // Remove one element from collection
    collection->pop_back(); 

    // Test to verify collection size is not greater thanequal to 15 elements
    ASSERT_FALSE(collection->size() >= 15);

    
}